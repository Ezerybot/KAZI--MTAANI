import {
  router, json, error, db, requireAuth, requireAdminEmailAllowlist
} from '@appdeploy/sdk';

type P = {
  name: string; category: string; region: string; district: string; phone: string;
  whatsapp: string; description: string; rating: number; reviews: number;
  status?: 'pending' | 'approved' | 'rejected';
};

type R = {
  providerId: string; rating: number; comment: string; createdAt: string;
};

const ADMIN_EMAILS = [
  'YOUR_REAL_ADMIN_EMAIL@example.com'
];

const seeds: P[] = [
  {name:'Juma Mussa',category:'Umeme / Electrician',region:'Dar es Salaam',district:'Kinondoni',phone:'+255712345678',whatsapp:'+255712345678',description:'Ufungaji wa umeme wa nyumba, shops, solar na matengenezo ya mifumo ya umeme.',rating:4.8,reviews:24,status:'approved'},
  {name:'Asha Plumbing',category:'Bomba / Plumber',region:'Dar es Salaam',district:'Ilala',phone:'+255713456789',whatsapp:'+255713456789',description:'Mabomba ya maji, sinki, vyoo, leaks na plumbing ya majumbani na biashara.',rating:4.6,reviews:18,status:'approved'},
  {name:'Musa Cooling Pro',category:'AC & Majokofu',region:'Arusha',district:'Arusha CBD',phone:'+255754321987',whatsapp:'+255754321987',description:'Service, installation na repair za AC, friji na cold rooms.',rating:4.9,reviews:31,status:'approved'},
  {name:'Baraka Auto Garage',category:'Ufundi Magari',region:'Mwanza',district:'Nyamagana',phone:'+255765432198',whatsapp:'+255765432198',description:'Engine diagnosis, service, brakes, suspension na electrical za magari.',rating:4.5,reviews:15,status:'approved'},
  {name:'Neema Clean Team',category:'Usafi / Cleaning',region:'Dodoma',district:'Dodoma CBD',phone:'+255716789012',whatsapp:'+255716789012',description:'Usafi wa nyumba, ofisi, sofa, carpets na deep cleaning.',rating:4.7,reviews:22,status:'approved'},
  {name:'Erick Electronics',category:'Vifaa vya Elektroniki',region:'Mbeya',district:'Mbeya Mjini',phone:'+255787654321',whatsapp:'+255787654321',description:'Repair za TV, radio, decoder, speakers na vifaa mbalimbali vya electronics.',rating:4.4,reviews:12,status:'approved'}
];

async function seed() {
  const x = await db.list<P>('providers', {limit: 10});
  if (!x.items.length) await db.add('providers', seeds);
}

const admin = [
  requireAuth(),
  requireAdminEmailAllowlist(ADMIN_EMAILS)
];

export const handler = router({
  'GET /api/_healthcheck': [async () => json({message:'Success'})],

  'GET /api/providers': [async () => {
    await seed();
    const x = await db.list<P>('providers', {limit: 100});
    return json({providers: x.items.filter((p) => p.status !== 'rejected')});
  }],

  'POST /api/providers': [async ({body}) => {
    const b = body as Record<string, unknown>;
    const required = ['name','phone','whatsapp','category','region','district','description'];
    if (required.some((x) => !String(b[x] || '').trim())) return error('Missing required fields', 400);

    const p: P = {
      name: String(b.name).trim(),
      phone: String(b.phone).trim(),
      whatsapp: String(b.whatsapp).trim(),
      category: String(b.category),
      region: String(b.region),
      district: String(b.district).trim(),
      description: String(b.description).trim(),
      rating: 0,
      reviews: 0,
      status: 'pending'
    };

    const [id] = await db.add('providers', [p]);
    if (!id) return error('Could not create provider', 500);
    return json({provider: {...p, id}}, 201);
  }],

  'GET /api/reviews': [async () => {
    const x = await db.list<R>('reviews', {limit: 200});
    return json({reviews: x.items});
  }],

  'POST /api/reviews': [async ({body}) => {
    const b = body as Record<string, unknown>;
    const pid = String(b.providerId || '');
    const rating = Number(b.rating);
    const comment = String(b.comment || '').trim();

    if (!pid || rating < 1 || rating > 5 || !comment) return error('Invalid review', 400);

    const [p] = await db.get<P>('providers', [pid]);
    if (!p) return error('Provider not found', 404);

    const r: R = {
      providerId: pid,
      rating,
      comment,
      createdAt: new Date().toISOString()
    };

    const [id] = await db.add('reviews', [r]);
    if (!id) return error('Could not create review', 500);

    const x = await db.list<R>('reviews', {limit: 200});
    const mine = x.items.filter((v) => v.providerId === pid);
    const avg = mine.reduce((s, v) => s + Number(v.rating), 0) / mine.length;
    const updated = {...p, rating: Number(avg.toFixed(1)), reviews: mine.length};

    await db.update('providers', [{id: pid, record: updated}]);
    return json({review: {...r, id}, provider: {...updated, id: pid}}, 201);
  }],

  'GET /api/admin/stats': [...admin, async () => {
    const ps = await db.list<P>('providers', {limit: 500});
    const rs = await db.list<R>('reviews', {limit: 500});
    return json({
      providers: ps.items.length,
      pending: ps.items.filter((p) => p.status === 'pending').length,
      approved: ps.items.filter((p) => p.status === 'approved' || !p.status).length,
      rejected: ps.items.filter((p) => p.status === 'rejected').length,
      reviews: rs.items.length
    });
  }],

  'PUT /api/admin/providers/:id/status': [...admin, async ({params, body}) => {
    const status = String((body as Record<string, unknown>)?.status || '');
    if (!['pending','approved','rejected'].includes(status)) return error('Invalid status', 400);

    const [provider] = await db.get<P>('providers', [params.id]);
    if (!provider) return error('Provider not found', 404);

    const updated = {...provider, status: status as P['status']};
    const [ok] = await db.update('providers', [{id: params.id, record: updated}]);
    if (!ok) return error('Could not update provider', 500);

    return json({provider: {...updated, id: params.id}});
  }],

  'DELETE /api/admin/providers/:id': [...admin, async ({params}) => {
    const [ok] = await db.delete('providers', [params.id]);
    if (!ok) return error('Could not delete provider', 500);
    return json({deleted: true});
  }],

  'DELETE /api/admin/reviews/:id': [...admin, async ({params}) => {
    const [review] = await db.get<R>('reviews', [params.id]);
    if (!review) return error('Review not found', 404);

    const [ok] = await db.delete('reviews', [params.id]);
    if (!ok) return error('Could not delete review', 500);

    const [provider] = await db.get<P>('providers', [review.providerId]);
    if (provider) {
      const x = await db.list<R>('reviews', {limit: 500});
      const mine = x.items.filter((v) => v.providerId === review.providerId);
      const avg = mine.length ? mine.reduce((s, v) => s + Number(v.rating), 0) / mine.length : 0;
      await db.update('providers', [{
        id: review.providerId,
        record: {...provider, rating: Number(avg.toFixed(1)), reviews: mine.length}
      }]);
    }

    return json({deleted: true});
  }]
});