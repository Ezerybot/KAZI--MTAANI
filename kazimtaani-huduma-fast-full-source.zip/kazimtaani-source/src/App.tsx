import { useEffect, useMemo, useState } from 'react';
import { api, auth } from '@appdeploy/client';
import {
  Search, MapPin, Star, Phone, MessageCircle, Plus, X, Wrench,
  UserRound, ChevronRight, ShieldCheck, LayoutDashboard, Users,
  Trash2, CheckCircle2, LogOut, MessageSquare, BarChart3
} from 'lucide-react';

type Provider = {
  id: string; name: string; category: string; region: string; district: string;
  phone: string; whatsapp: string; description: string; rating: number;
  reviews: number; status?: 'pending' | 'approved' | 'rejected';
};

type Review = {
  id: string; providerId: string; rating: number; comment: string; createdAt: string;
};

const cats = ['Zote', 'Umeme / Electrician', 'Bomba / Plumber', 'AC & Majokofu',
  'Ufundi Magari', 'Usafi / Cleaning', 'Vifaa vya Elektroniki'];

const regions = ['Zote', 'Dar es Salaam', 'Mwanza', 'Arusha', 'Dodoma', 'Mbeya',
  'Morogoro', 'Tanga', 'Kilimanjaro'];

function App() {
  const [providers, setProviders] = useState<Provider[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [q, setQ] = useState('');
  const [region, setRegion] = useState('Zote');
  const [cat, setCat] = useState('Zote');
  const [selected, setSelected] = useState<Provider | null>(null);
  const [register, setRegister] = useState(false);
  const [admin, setAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [adminUser, setAdminUser] = useState<any>(null);

  const load = async () => {
    try {
      const [a, b] = await Promise.all([
        api.get('/api/providers'),
        api.get('/api/reviews')
      ]);
      setProviders(a.data.providers || []);
      setReviews(b.data.reviews || []);
    } catch {
      setError('Taarifa za seva hazikupatikana. Jaribu tena.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    void auth.getUser().then(setAdminUser);
  }, []);

  const list = useMemo(() => providers.filter((p) => {
    const s = q.toLowerCase().trim();
    return (!s || [p.name, p.category, p.description, p.region, p.district]
      .join(' ').toLowerCase().includes(s))
      && (region === 'Zote' || p.region === region)
      && (cat === 'Zote' || p.category === cat)
      && p.status !== 'rejected';
  }), [providers, q, region, cat]);

  const addProvider = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');
    const d = Object.fromEntries(new FormData(e.currentTarget).entries());
    if (Object.values(d).some((v) => !String(v).trim())) {
      setError('Tafadhali jaza sehemu zote muhimu.');
      return;
    }
    try {
      const r = await api.post('/api/providers', d);
      setProviders((x) => [r.data.provider, ...x]);
      setRegister(false);
      e.currentTarget.reset();
    } catch {
      setError('Usajili umeshindikana.');
    }
  };

  const addReview = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selected) return;
    const d = Object.fromEntries(new FormData(e.currentTarget).entries());
    if (!d.rating || !d.comment) {
      setError('Chagua nyota na andika maoni.');
      return;
    }
    try {
      const r = await api.post('/api/reviews', {
        providerId: selected.id,
        rating: Number(d.rating),
        comment: String(d.comment)
      });
      setReviews((x) => [r.data.review, ...x]);
      setProviders((x) => x.map((p) => p.id === r.data.provider.id ? r.data.provider : p));
      setSelected(r.data.provider);
      e.currentTarget.reset();
    } catch {
      setError('Review haijatumwa.');
    }
  };

  const openAdmin = async () => {
    const user = await auth.getUser();
    if (!user) {
      try {
        const result = await auth.signIn();
        setAdminUser(result.user);
        setAdmin(true);
      } catch {
        setError('Login ya Admin imeghairiwa au imekataa.');
      }
    } else {
      setAdminUser(user);
      setAdmin(true);
    }
  };

  if (admin) {
    return <AdminDashboard
      user={adminUser}
      providers={providers}
      reviews={reviews}
      onClose={() => setAdmin(false)}
      onReload={load}
    />;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="sticky top-0 z-30 border-b bg-white/95 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-blue-700 text-white">
              <Wrench size={21} />
            </div>
            <div>
              <b className="text-lg text-blue-800">KaziMtaani</b>
              <div className="text-[10px] font-bold uppercase tracking-widest text-emerald-600">Huduma Fast</div>
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={openAdmin} className="flex items-center gap-2 rounded-xl bg-slate-900 px-3 py-2 text-sm font-bold text-white">
              <LayoutDashboard size={17} /><span className="hidden sm:inline">Admin</span>
            </button>
            <button onClick={() => setRegister(true)} className="flex items-center gap-2 rounded-xl bg-emerald-600 px-3 py-2 text-sm font-bold text-white">
              <Plus size={17} /><span className="hidden sm:inline">Sajili Huduma Yako</span><span className="sm:hidden">Sajili</span>
            </button>
          </div>
        </div>
      </header>

      <section className="bg-gradient-to-br from-blue-800 via-blue-700 to-emerald-700 px-4 pb-10 pt-10 text-white">
        <div className="mx-auto max-w-6xl">
          <span className="inline-flex items-center gap-1 rounded-full bg-white/10 px-3 py-1 text-xs font-bold">
            <ShieldCheck size={14} /> Mafundi wa karibu nawe
          </span>
          <h1 className="mt-4 text-3xl font-black sm:text-5xl">Pata fundi sahihi. <span className="text-emerald-300">Kwa haraka.</span></h1>
          <p className="mt-3 max-w-2xl text-sm text-blue-100 sm:text-base">Tafuta mafundi na watoa huduma waaminifu Tanzania, wasiliana nao moja kwa moja.</p>
          <div className="mt-7 grid gap-3 rounded-2xl bg-white p-3 shadow-2xl sm:grid-cols-[1fr_220px]">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={19} />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tafuta fundi, huduma au jina..." className="w-full rounded-xl bg-slate-50 py-3 pl-10 text-sm text-slate-900 outline-none ring-1 ring-slate-200" />
            </div>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <select value={region} onChange={(e) => setRegion(e.target.value)} className="w-full rounded-xl bg-slate-50 py-3 pl-10 text-sm font-semibold text-slate-800 ring-1 ring-slate-200">
                {regions.map((x) => <option key={x}>{x}</option>)}
              </select>
            </div>
          </div>
        </div>
      </section>

      <main className="mx-auto max-w-6xl px-4 py-5">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {cats.map((x) => <button key={x} onClick={() => setCat(x)} className={`whitespace-nowrap rounded-full px-4 py-2 text-xs font-bold ${cat === x ? 'bg-blue-700 text-white' : 'bg-white text-slate-600 ring-1 ring-slate-200'}`}>{x}</button>)}
        </div>
        {error && <div className="mt-3 rounded-xl bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-800">{error}</div>}
        <div className="mt-5">
          <h2 className="text-xl font-black">Watoa huduma karibu</h2>
          <p className="text-sm text-slate-500">{loading ? 'Inapakia...' : `${list.length} mtoa huduma anapatikana`}</p>
        </div>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((p) => <Card key={p.id} p={p} open={() => setSelected(p)} />)}
        </div>
        {!loading && !list.length && <div className="mt-5 rounded-2xl bg-white py-14 text-center ring-1 ring-slate-200"><UserRound className="mx-auto text-slate-300" size={38} /><p className="mt-3 font-bold">Hakuna mtoa huduma anayelingana.</p></div>}
      </main>

      {selected && <Modal close={() => { setSelected(null); setError(''); }}><Profile p={selected} reviews={reviews.filter((r) => r.providerId === selected.id)} submit={addReview} close={() => setSelected(null)} /></Modal>}
      {register && <Modal close={() => setRegister(false)}><Register submit={addProvider} close={() => setRegister(false)} /></Modal>}
      <footer className="border-t bg-white py-7 text-center text-xs text-slate-500">© 2026 KaziMtaani / Huduma Fast</footer>
    </div>
  );
}

function Card({ p, open }: { p: Provider; open: () => void }) {
  const wa = `https://wa.me/${p.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(`Habari ${p.name}, nimepata huduma yako kupitia KaziMtaani. Naomba maelezo zaidi.`)}`;
  return (
    <article onClick={open} className="group cursor-pointer rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200 hover:shadow-md">
      <div className="flex gap-3">
        <div className="grid h-12 w-12 place-items-center rounded-2xl bg-blue-50 text-blue-700"><UserRound size={24} /></div>
        <div className="min-w-0 flex-1">
          <div className="flex justify-between"><h3 className="truncate font-black">{p.name}</h3><ChevronRight size={17} /></div>
          <span className="mt-1 inline-block rounded-full bg-emerald-50 px-2 py-1 text-[11px] font-bold text-emerald-700">{p.category}</span>
        </div>
      </div>
      <div className="mt-3 flex items-center gap-2 text-xs text-slate-500"><MapPin size={14} />{p.district}, {p.region}</div>
      <Stars n={p.rating} count={p.reviews} />
      <div className="mt-4 grid grid-cols-2 gap-2" onClick={(e) => e.stopPropagation()}>
        <a href={`tel:${p.phone}`} className="flex items-center justify-center gap-2 rounded-xl bg-blue-700 py-2.5 text-xs font-bold text-white"><Phone size={15} />Piga Simu</a>
        <a href={wa} target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 rounded-xl bg-emerald-600 py-2.5 text-xs font-bold text-white"><MessageCircle size={15} />WhatsApp</a>
      </div>
    </article>
  );
}

function Stars({ n, count }: { n: number; count: number }) {
  return <div className="mt-3 flex items-center gap-1"><div className="flex text-amber-400">{[1,2,3,4,5].map((i) => <Star key={i} size={14} fill={i <= Math.round(n) ? 'currentColor' : 'none'} />)}</div><b className="text-xs">{Number(n || 0).toFixed(1)}</b>{count >= 0 && <span className="text-xs text-slate-400">({count})</span>}</div>;
}

function Modal({ children, close }: { children: React.ReactNode; close: () => void }) {
  return <div className="fixed inset-0 z-50 grid place-items-end bg-slate-950/50 p-0 sm:place-items-center sm:p-4" onMouseDown={(e) => e.target === e.currentTarget && close()}><div className="max-h-[92vh] w-full overflow-y-auto rounded-t-3xl bg-white p-5 shadow-2xl sm:max-w-lg sm:rounded-3xl">{children}</div></div>;
}

function Profile({ p, reviews, submit, close }: { p: Provider; reviews: Review[]; submit: (e: React.FormEvent<HTMLFormElement>) => void; close: () => void }) {
  const wa = `https://wa.me/${p.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(`Habari ${p.name}, nimepata huduma yako kupitia KaziMtaani. Naomba maelezo zaidi.`)}`;
  return <>
    <div className="flex justify-between"><div className="flex gap-3"><div className="grid h-14 w-14 place-items-center rounded-2xl bg-blue-50 text-blue-700"><UserRound size={28} /></div><div><h2 className="text-xl font-black">{p.name}</h2><b className="text-xs text-emerald-700">{p.category}</b><div className="text-xs text-slate-500">{p.district}, {p.region}</div></div></div><button onClick={close}><X /></button></div>
    <p className="mt-5 text-sm leading-6 text-slate-600">{p.description}</p>
    <div className="mt-4 rounded-xl bg-slate-50 p-3"><Stars n={p.rating} count={p.reviews} /></div>
    <div className="mt-4 grid grid-cols-2 gap-2"><a href={`tel:${p.phone}`} className="btn bg-blue-700"><Phone size={16} />Piga Simu</a><a href={wa} target="_blank" rel="noreferrer" className="btn bg-emerald-600"><MessageCircle size={16} />Tuma WhatsApp</a></div>
    <h3 className="mt-6 font-black">Maoni ya wateja</h3>
    <div className="mt-3 space-y-2">{reviews.slice(0, 5).map((r) => <div key={r.id} className="rounded-xl bg-slate-50 p-3"><Stars n={r.rating} count={0} /><p className="text-sm text-slate-700">{r.comment}</p></div>)}{!reviews.length && <p className="text-sm text-slate-500">Bado hakuna maoni.</p>}</div>
    <form onSubmit={submit} className="mt-6 border-t pt-5"><h3 className="font-black">Acha rating yako</h3><select name="rating" defaultValue="" required className="field mt-3"><option value="" disabled>Chagua nyota</option>{[5,4,3,2,1].map((n) => <option key={n}>{n}</option>)}</select><textarea name="comment" required minLength={3} placeholder="Andika maoni mafupi..." className="field mt-2 min-h-24" /><button className="mt-2 w-full rounded-xl bg-blue-700 py-3 font-bold text-white">Tuma Review</button></form>
  </>;
}

function Register({ submit, close }: { submit: (e: React.FormEvent<HTMLFormElement>) => void; close: () => void }) {
  return <>
    <div className="flex justify-between"><div><h2 className="text-xl font-black">Sajili Huduma Yako</h2><p className="text-sm text-slate-500">Fanya huduma yako ionekane kwa wateja.</p></div><button onClick={close}><X /></button></div>
    <form onSubmit={submit} className="mt-5 space-y-3">
      <input name="name" required placeholder="Jina kamili" className="field" />
      <div className="grid grid-cols-2 gap-3"><input name="phone" required placeholder="Namba ya simu" className="field" /><input name="whatsapp" required placeholder="Namba ya WhatsApp" className="field" /></div>
      <select name="category" required defaultValue="" className="field"><option value="" disabled>Chagua huduma</option>{cats.slice(1).map((x) => <option key={x}>{x}</option>)}</select>
      <div className="grid grid-cols-2 gap-3"><select name="region" required defaultValue="" className="field"><option value="" disabled>Mkoa</option>{regions.slice(1).map((x) => <option key={x}>{x}</option>)}</select><input name="district" required placeholder="Wilaya / Eneo" className="field" /></div>
      <textarea name="description" required minLength={10} placeholder="Eleza huduma unazotoa..." className="field min-h-28" />
      <button className="w-full rounded-xl bg-emerald-600 py-3 font-bold text-white">Sajili Huduma</button>
    </form>
  </>;
}

function AdminDashboard({ user, providers, reviews, onClose, onReload }: { user: any; providers: Provider[]; reviews: Review[]; onClose: () => void; onReload: () => Promise<void> }) {
  const [tab, setTab] = useState<'overview' | 'providers' | 'reviews'>('overview');
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState('');

  const action = async (id: string, type: 'approve' | 'reject' | 'delete') => {
    setBusy(id + type);
    setMsg('');
    try {
      if (type === 'delete') await api.delete(`/api/admin/providers/${id}`);
      else await api.put(`/api/admin/providers/${id}/status`, { status: type === 'approve' ? 'approved' : 'rejected' });
      await onReload();
      setMsg('Mabadiliko yamehifadhiwa.');
    } catch {
      setMsg('Admin action imeshindikana.');
    } finally {
      setBusy('');
    }
  };

  const deleteReview = async (id: string) => {
    setBusy(id);
    try {
      await api.delete(`/api/admin/reviews/${id}`);
      await onReload();
      setMsg('Review imefutwa.');
    } catch {
      setMsg('Review haijafutwa.');
    } finally {
      setBusy('');
    }
  };

  const signOut = async () => {
    await auth.signOut();
    onClose();
  };

  return <div className="min-h-screen bg-slate-100">
    <header className="border-b bg-white"><div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4"><div><h1 className="text-xl font-black text-blue-800">KaziMtaani Admin</h1><p className="text-xs text-slate-500">{user?.email || user?.name || 'Admin'}</p></div><div className="flex gap-2"><button onClick={onClose} className="rounded-xl bg-slate-100 px-3 py-2 text-sm font-bold">Tovuti</button><button onClick={signOut} className="flex items-center gap-2 rounded-xl bg-slate-900 px-3 py-2 text-sm font-bold text-white"><LogOut size={15} />Toka</button></div></div></header>
    <main className="mx-auto max-w-7xl px-4 py-6">
      <div className="flex flex-wrap gap-2">{[['overview','Overview',BarChart3],['providers','Mafundi',Users],['reviews','Reviews',MessageSquare]].map(([key,label,Icon]: any) => <button key={key} onClick={() => setTab(key)} className={`flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold ${tab === key ? 'bg-blue-700 text-white' : 'bg-white text-slate-600 ring-1 ring-slate-200'}`}><Icon size={16} />{label}</button>)}</div>
      {msg && <div className="mt-4 rounded-xl bg-emerald-50 p-3 text-sm font-bold text-emerald-700">{msg}</div>}
      {tab === 'overview' && <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[
        ['Mafundi wote', providers.length, Users], ['Walioidhinishwa', providers.filter((p) => p.status !== 'pending' && p.status !== 'rejected').length, CheckCircle2],
        ['Pending', providers.filter((p) => p.status === 'pending').length, ShieldCheck], ['Reviews', reviews.length, MessageSquare]
      ].map(([label,value,Icon]: any) => <div className="panel p-5" key={label}><Icon className="text-blue-700" /><p className="mt-4 text-3xl font-black">{value}</p><p className="text-sm text-slate-500">{label}</p></div>)}</div>}
      {tab === 'providers' && <div className="mt-5 panel overflow-hidden"><div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="bg-slate-50"><tr><th className="p-3">Fundi</th><th className="p-3">Huduma</th><th className="p-3">Eneo</th><th className="p-3">Status</th><th className="p-3">Actions</th></tr></thead><tbody>{providers.map((p) => <tr key={p.id} className="border-t"><td className="p-3 font-bold">{p.name}</td><td className="p-3">{p.category}</td><td className="p-3">{p.district}, {p.region}</td><td className="p-3"><span className="rounded-full bg-slate-100 px-2 py-1 text-xs font-bold">{p.status || 'approved'}</span></td><td className="p-3"><div className="flex flex-wrap gap-2">{p.status === 'pending' && <button disabled={!!busy} onClick={() => action(p.id,'approve')} className="rounded-lg bg-emerald-600 px-2 py-1 text-xs font-bold text-white">Approve</button>}<button disabled={!!busy} onClick={() => action(p.id, p.status === 'rejected' ? 'approve' : 'reject')} className="rounded-lg bg-amber-500 px-2 py-1 text-xs font-bold text-white">{p.status === 'rejected' ? 'Restore' : 'Reject'}</button><button disabled={!!busy} onClick={() => action(p.id,'delete')} className="rounded-lg bg-red-600 px-2 py-1 text-xs font-bold text-white"><Trash2 size={13} /></button></div></td></tr>)}</tbody></table></div></div>}
      {tab === 'reviews' && <div className="mt-5 grid gap-3">{reviews.map((r) => { const p = providers.find((x) => x.id === r.providerId); return <div key={r.id} className="panel p-4"><div className="flex items-start justify-between gap-4"><div><b>{p?.name || 'Fundi aliyefutwa'}</b><Stars n={r.rating} count={0} /><p className="mt-2 text-sm text-slate-600">{r.comment}</p></div><button disabled={!!busy} onClick={() => deleteReview(r.id)} className="rounded-xl bg-red-50 p-2 text-red-600"><Trash2 size={16} /></button></div></div>; })}</div>}
    </main>
  </div>;
}

export default App;